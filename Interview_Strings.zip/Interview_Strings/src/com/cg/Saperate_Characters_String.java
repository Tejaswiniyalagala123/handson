package com.cg;

public class Saperate_Characters_String {

	public static void main(String[] args) {
		String str="CHARACTER";
		for(int i=0;i<str.length();i++) {
			System.out.println(str.charAt(i));
		}
	}

}
