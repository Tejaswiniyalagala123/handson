package com.cg;

 enum myLevel{
	 LOW,
	  MEDIUM,
	  HIGH
}
public class Enumm {

	public static void main(String[] args) {
		myLevel myVar=myLevel.MEDIUM;
		System.out.println(myVar);
	}

}
