package com.cg;

public class keyFinal {
	final int speedlimit=90;
	//if you make any variable is final we can't change it
	// If you make any method as final, you cannot override it.
	// If you make any class as final, you cannot extend it.
	void run() {
	//	speedlimit=400;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		keyFinal a=new keyFinal();
		a.run();
	}

}
