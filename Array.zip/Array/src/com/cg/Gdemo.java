package com.cg;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Properties;

class Gdemo {
	public static void main(String[]args) {
		String c=" Hello World ";
		String s=c.trim();
		System.out.println("\""+s+"\"");
		
//		try {
//			System.out.println("Hello" +" " + 1/0);
//		}catch(ArithmeticException e){
//			System.out.println("world");
//			
//		}
 
// try {
//	 int i,sum;
//	 sum=10;
//	 for(i=-1;i<3;++i) {
//		 sum=(sum/i);
//		 System.out.println(i);
//	 }
//	 
// }catch(ArithmeticException e){
//	 System.out.println("0");
// }
 
 }
}
