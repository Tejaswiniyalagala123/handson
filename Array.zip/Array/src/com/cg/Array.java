package com.cg;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Array {

	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter Array Size");
//        int s=sc.nextInt();
//        
//        int a[]=new int[s];
//        System.out.println("Enter Array Elements");
//        for(int i=0;i<s;i++) {
//        	a[i]=sc.nextInt();
//        }
//        System.out.println("Enter Array Location ");
//        int loc=sc.nextInt();
////        if(s>loc) {
//        for(int i=loc;i<s-1;i++) {        
//        	a[i]=a[i+1];
//        	
//        }
//        s--;     //remove particular index from array
////        }
////        else {
////        	System.out.println("Array out of index");
////        }
//        for(int i=0;i<s;i++) {
//        	System.out.println(a[i]+" ");
//        }
//		int[] arr;
//	      try{
//	          arr[5]=3;
//	          arr=new int[6];
//	          System.out.println("memory allocated");
//	      }catch(Exception e){
//	          System.out.println("Exception Occured");
//	      }
//		List<Integer> identify =new ArrayList<Integer>();
//		Object[] objects =identify.toArray();
//		
		List list=new ArrayList<Integer>();
		list.add("hello");
		System.out.println(list);
	}

}
