package com.cg;

public class PowerOfNumber {

	
	public static void main(String[] args) {
		int B=2,P=3,power=1;
		for(int i=0;i<P;i++) {
			power=power*B;
		}
		System.out.println(power);
		

	}

}
