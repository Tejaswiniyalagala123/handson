package com.cg;

public class Guess {

	public static void main(String[] args) {
		String s="korukonda";
		for(int i=0;i<=s.length();i++) {
			char ch=s.charAt(0);
			System.out.println(ch);
		}
	}

}
