package com.cg;

public class Wrapper_Checking {

	public static void main(String[] args) {
		Integer num1=100;
		Integer num2=100;
		Integer num3=500;
		Integer num4=500;
		
		//integers in the range of -128 to 127 
		if(num1==num2) {
			System.out.println("num1 = num2");
		}else {
			System.out.println("num1 != num2");
		}
		//is out of the range so its not true
		if(num3==num4) {
			System.out.println("num3 = num4");
		}else {
			System.out.println("num3 != num4");
		}
	}
	
	//In Java, the == operator is used to compare primitive data types for equality,
	//but when it comes to objects  it compares the references, not the actual values. 


}
